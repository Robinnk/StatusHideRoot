Status Hide Root — Android source project

यह ready-made APK नहीं, source code है। Android Studio/SDK और Gradle से build करना होगा।

Features: Root (su) के माध्यम से secure setting icon_blacklist में battery, mobile और wifi entries जोड़ना/हटाना। Restore इन तीन entries को हटाता है और दूसरी entries बचाता है।

महत्वपूर्ण: Android 16 / Nothing OS पर SystemUI icon_blacklist को अनदेखा कर सकता है, इसलिए काम करने की गारंटी नहीं है। Root manager में ऐप को अनुमति देना आवश्यक है। यह ऐप सिस्टम फाइलें नहीं बदलता।

Build: Android Studio में project खोलें, Gradle sync करें, फिर app > assembleDebug चलाएँ। Gradle wrapper और compiled APK इस ZIP में शामिल नहीं हैं।
